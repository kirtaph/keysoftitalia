<?php
// Redirect to main services page
header('Location: ../servizi.php');
exit;
?>